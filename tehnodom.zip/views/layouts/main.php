<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Технодом</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="container">
        <? require_once $content;?>
    </div>
    <footer>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="/js/main.js"></script>
    </footer>
</body>
</html>